package com.example.pruebaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> listaSensores;
    private EditText nombreSensorInput, ubicacionSensorInput;
    private Spinner tipoSensorSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaSensores = new ArrayList<>();
        nombreSensorInput = findViewById(R.id.nombre_sensor_input);
        ubicacionSensorInput = findViewById(R.id.ubicacion_sensor_input);
        tipoSensorSpinner = findViewById(R.id.tipo_sensor_spinner);

        // opciones "Humedad" y "Temperatura"
        ArrayAdapter<CharSequence> adaptadorSpinner = ArrayAdapter.createFromResource(this,
                R.array.tipos_sensores, android.R.layout.simple_spinner_item);
        adaptadorSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipoSensorSpinner.setAdapter(adaptadorSpinner);

        Button botonAgregarSensor = findViewById(R.id.boton_agregar_sensor);
        Button botonHistorial = findViewById(R.id.boton_historial);

        // agregar un sensor
        botonAgregarSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombreSensor = nombreSensorInput.getText().toString();
                String ubicacionSensor = ubicacionSensorInput.getText().toString();
                String tipoSensor = tipoSensorSpinner.getSelectedItem().toString();

                if (!nombreSensor.isEmpty() && !ubicacionSensor.isEmpty()) {
                    // Guardar los datos del sensor en la lista
                    String sensor = "Nombre: " + nombreSensor + ", Ubicación: " + ubicacionSensor + ", Tipo: " + tipoSensor;
                    listaSensores.add(sensor);

                    Toast.makeText(MainActivity.this, "Sensor agregado: " + nombreSensor, Toast.LENGTH_SHORT).show();

                    // Limpiar los campos
                    nombreSensorInput.setText("");
                    ubicacionSensorInput.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Ingrese el nombre y la ubicación del sensor", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //abrir el historial
        botonHistorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HistorialActivity.class);
                intent.putStringArrayListExtra("sensores", listaSensores);  // Pasar la lista de sensores
                startActivity(intent);
            }
        });
    }
}


