package com.example.pruebaapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SensorActivity extends AppCompatActivity {

    private EditText sensorNameInput, sensorLocationInput, sensorTypeInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);


        sensorNameInput = findViewById(R.id.sensor_name_input);
        sensorLocationInput = findViewById(R.id.sensor_location_input);
        sensorTypeInput = findViewById(R.id.sensor_type_input);


        String sensorType = getIntent().getStringExtra("sensor_type");
        if (sensorType != null) {
            sensorTypeInput.setText(sensorType.equals("temperature") ? "Temperatura" : "Humedad");
        }

        // Config botones
        Button searchButton = findViewById(R.id.button_search);
        Button addButton = findViewById(R.id.button_add);
        Button modifyButton = findViewById(R.id.button_modify);
        Button deleteButton = findViewById(R.id.button_delete);
        Button backButton = findViewById(R.id.button_back);

        // buscar un sensor
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sensorName = sensorNameInput.getText().toString();
                Toast.makeText(SensorActivity.this, "Buscar sensor: " + sensorName, Toast.LENGTH_SHORT).show();

            }
        });

        // agregar un sensor
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sensorName = sensorNameInput.getText().toString();
                String sensorLocation = sensorLocationInput.getText().toString();
                String sensorType = sensorTypeInput.getText().toString();
                Toast.makeText(SensorActivity.this, "Ingresar sensor: " + sensorName + " en " + sensorLocation + " de tipo " + sensorType, Toast.LENGTH_SHORT).show();

            }
        });

        // modificar un sensor
        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sensorName = sensorNameInput.getText().toString();
                Toast.makeText(SensorActivity.this, "Modificar sensor: " + sensorName, Toast.LENGTH_SHORT).show();

            }
        });

        // eliminar un sensor
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sensorName = sensorNameInput.getText().toString();
                Toast.makeText(SensorActivity.this, "Eliminar sensor: " + sensorName, Toast.LENGTH_SHORT).show();
                // Lógica para eliminar sensor (a implementar)
            }
        });

        // volver a la pantalla anterior
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
