package com.example.pruebaapp;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SensorAdaptador extends RecyclerView.Adapter<SensorAdaptador.SensorViewHolder> {

    private List<String> listaSensores;
    private int sensorSeleccionado = -1;

    public SensorAdaptador(List<String> listaSensores) {
        this.listaSensores = listaSensores;
    }

    @NonNull
    @Override
    public SensorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sensor, parent, false);
        return new SensorViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull SensorViewHolder holder, int position) {
        String sensor = listaSensores.get(position);
        holder.nombreSensor.setText(sensor);


        if (position == sensorSeleccionado) {
            holder.itemView.setBackgroundColor(Color.LTGRAY);
        } else {
            holder.itemView.setBackgroundColor(Color.WHITE);
        }

        // Detectar cuando se selecciona un sensor
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sensorSeleccionado = position;
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaSensores.size();
    }


    public int getSensorSeleccionado() {
        return sensorSeleccionado;
    }

    // modificar un sensor en la lista
    public void modificarSensor(int index, String nuevoValor) {
        listaSensores.set(index, nuevoValor);
        notifyItemChanged(index);
    }

    // eliminar un sensor de la lista
    public void eliminarSensor(int index) {
        listaSensores.remove(index);
        notifyItemRemoved(index);
    }

    public static class SensorViewHolder extends RecyclerView.ViewHolder {
        TextView nombreSensor;

        public SensorViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreSensor = itemView.findViewById(R.id.nombre_sensor);
        }
    }
}

