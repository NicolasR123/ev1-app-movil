package com.example.pruebaapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HistorialActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SensorAdaptador sensorAdaptador;
    private ArrayList<String> listaSensores;
    private ArrayList<String> listaSensoresCompleta;
    private EditText inputBuscar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        recyclerView = findViewById(R.id.recycler_sensores);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaSensores = getIntent().getStringArrayListExtra("sensores");

        if (listaSensores == null) {
            listaSensores = new ArrayList<>();
        }

        listaSensoresCompleta = new ArrayList<>(listaSensores);

        sensorAdaptador = new SensorAdaptador(listaSensores);
        recyclerView.setAdapter(sensorAdaptador);

        inputBuscar = findViewById(R.id.input_buscar);
        Button botonBuscar = findViewById(R.id.button_buscar);

        // Botón buscar un sensor por nombre
        botonBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarSensorPorNombre();
            }
        });

        // Botón modificar un sensor
        Button botonModificar = findViewById(R.id.boton_modificar);
        botonModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sensorSeleccionado = sensorAdaptador.getSensorSeleccionado();
                if (sensorSeleccionado == -1) {
                    Toast.makeText(HistorialActivity.this, getString(R.string.sensor_select_error), Toast.LENGTH_SHORT).show();
                    return;
                }
                mostrarDialogoModificar(sensorSeleccionado);
            }
        });

        // Botón eliminar un sensor
        Button botonEliminar = findViewById(R.id.boton_eliminar);
        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sensorSeleccionado = sensorAdaptador.getSensorSeleccionado();
                if (sensorSeleccionado == -1) {
                    Toast.makeText(HistorialActivity.this, getString(R.string.sensor_select_error), Toast.LENGTH_SHORT).show();
                    return;
                }
                sensorAdaptador.eliminarSensor(sensorSeleccionado);
                Toast.makeText(HistorialActivity.this, getString(R.string.sensor_deleted), Toast.LENGTH_SHORT).show();
            }
        });
    }

    //buscar sensores por nombre
    private void buscarSensorPorNombre() {
        String nombreBuscado = inputBuscar.getText().toString().trim();

        if (TextUtils.isEmpty(nombreBuscado)) {
            // Si el campo de búsqueda está vacío, restablecemos la lista completa
            listaSensores.clear();
            listaSensores.addAll(listaSensoresCompleta);
            sensorAdaptador.notifyDataSetChanged();
            Toast.makeText(this, "Lista restaurada", Toast.LENGTH_SHORT).show();
            return;
        }


        List<String> listaFiltrada = new ArrayList<>();
        for (String sensor : listaSensoresCompleta) {
            if (sensor.toLowerCase().contains(nombreBuscado.toLowerCase())) {
                listaFiltrada.add(sensor);
            }
        }


        listaSensores.clear();
        listaSensores.addAll(listaFiltrada);
        sensorAdaptador.notifyDataSetChanged();

        if (listaFiltrada.isEmpty()) {
            Toast.makeText(this, "No se encontraron resultados", Toast.LENGTH_SHORT).show();
        }
    }


    private void mostrarDialogoModificar(int sensorIndex) {

    }
}

